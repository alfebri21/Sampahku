package com.example.sampahku


class ModelMain {
    lateinit var strName: String
    lateinit var strVicinity: String
    var latLoc = 0.0
    var longLoc = 0.0
}